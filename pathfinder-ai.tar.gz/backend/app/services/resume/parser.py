"""
Resume parser service - extracts text from PDF and images
Adapted from resume-analyzer-main/src/file_reader.py
"""
import os
from pathlib import Path
from typing import Optional
import cv2
import numpy as np
from pdf2image import convert_from_path
from pypdf import PdfReader
import pytesseract
from app.config import settings


class ResumeParser:
    """Parse resumes from PDF and image files"""
    
    def __init__(self):
        self.upload_dir = settings.UPLOAD_DIR
    
    async def extract_text_from_pdf(self, file_path: str, preserve_case: bool = False) -> str:
        """
        Extract text from PDF file (all pages).

        Args:
            file_path: Path to PDF file
            preserve_case: If True, do not lowercase (use for transcripts/grade reports).

        Returns:
            Extracted text content
        """
        try:
            reader = PdfReader(file_path)
            data = ""
            for page in reader.pages:
                data = data + (page.extract_text() or "") + "\n"
            data = data.strip()
            if not preserve_case:
                data = data.lower()
            return data
        except Exception as e:
            raise Exception(f"Error extracting text from PDF: {str(e)}")
    
    async def extract_text_from_image(self, file_path: str) -> str:
        """
        Extract text from image PDF using OCR
        
        Args:
            file_path: Path to PDF file (with images)
            
        Returns:
            Extracted text content
        """
        try:
            pages = convert_from_path(file_path)
            extracted_text = []
            for page in pages:
                # Preprocess the image (deskew)
                preprocessed_image = self._deskew(np.array(page))
                # Extract text using OCR
                text = self._get_text_from_image(preprocessed_image)
                extracted_text.append(text)
            return "\n".join(extracted_text).strip().lower()
        except Exception as e:
            raise Exception(f"Error extracting text from image: {str(e)}")
    
    async def parse_resume(self, file_path: str, preserve_case: bool = False) -> str:
        """
        Parse resume or transcript file (PDF or image).

        Args:
            file_path: Path to PDF/image file
            preserve_case: If True, do not lowercase (use for transcripts/grade reports).

        Returns:
            Extracted text content
        """
        # Try PDF text extraction first
        data = await self.extract_text_from_pdf(file_path, preserve_case=preserve_case)
        # If extraction yields very little text, try OCR (resume parser uses lowercased OCR)
        if len(data) <= 100:
            data = await self.extract_text_from_image(file_path)
            if preserve_case:
                data = data  # OCR already returns mixed case
            # else keep .lower() from extract_text_from_image
        return data
    
    @staticmethod
    def _deskew(image: np.ndarray) -> np.ndarray:
        """
        Deskew the given image to correct any tilt
        
        Args:
            image: Image array
            
        Returns:
            Deskewed image
        """
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray = cv2.bitwise_not(gray)
        coords = np.column_stack(np.where(gray > 0))
        
        if len(coords) == 0:
            return image
        
        angle = cv2.minAreaRect(coords)[-1]
        
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        
        (h, w) = image.shape[:2]
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(
            image, M, (w, h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE
        )
        return rotated
    
    @staticmethod
    def _get_text_from_image(image: np.ndarray) -> str:
        """
        Extract text from image using OCR
        
        Args:
            image: Image array
            
        Returns:
            Extracted text
        """
        try:
            text = pytesseract.image_to_string(image)
            return text
        except Exception as e:
            raise Exception(f"OCR error: {str(e)}")
