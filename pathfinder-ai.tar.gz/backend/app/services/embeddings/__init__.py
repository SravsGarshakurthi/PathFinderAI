# Embedding services
