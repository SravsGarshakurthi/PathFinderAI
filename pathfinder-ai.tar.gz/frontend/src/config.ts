/**
 * API base URL. In production (Docker), VITE_API_BASE is /api/v1 (relative).
 * In development, defaults to localhost backend.
 */
export const API_BASE =
  (import.meta.env.VITE_API_BASE as string) || 'http://localhost:8000/api/v1'
